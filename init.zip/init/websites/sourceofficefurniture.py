from playwright.sync_api import sync_playwright
import pandas as pd

from models.product import Product

BASE_URL = "https://www.sourceofficefurniture.ca"

def collect_data(page_url=BASE_URL, max_items=10):
    with sync_playwright() as p:
        products = []

        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(BASE_URL)

        # Choose default store
        select_store_modal = page.query_selector("#select-store-modal")
        if select_store_modal:
            page.query_selector(".stores-select-list-item-button").click()

        # Collect list shops
        page.goto(f"{BASE_URL}/shop")
        shops = page.query_selector_all(".thumbnail")
        shop_links = []
        for shop in shops:
            shop_links.append(f"{BASE_URL}{shop.query_selector(":scope > *").get_attribute("href")}")

        # Collect products
        for shop_link in shop_links[:1]:
            # Visit shops & categories
            page.goto(shop_link)
            categories = page.query_selector_all(".thumbnail")
            for category in categories:
                try:
                    page.goto(f"{BASE_URL}{category.query_selector(":scope > *").get_attribute("href")}")
                    max_page_number = page.evaluate("""() => {
                        const links = Array.from(document.querySelectorAll('ul.pagination > li > a')).map(a => a.textContent.trim());
                        const page_numbers = links.filter(link => !isNaN(link)).map(Number);
                        return Math.max(...page_numbers);
                    }""")

                    # Construct all pagination links
                    pagination_urls = [f'{page.url}?p={i}' for i in range(1, 2 + 1)]

                    product_detail_links = []
                    for pagination_url in pagination_urls:
                        page.goto(pagination_url)
                        for product_link in page.locator('.product-details-link').all():
                            product_detail_links.append(product_link.get_attribute("href"))

                    for product_detail_link in product_detail_links:
                        product_data = Product()
                        product_url = f"{BASE_URL}{product_detail_link}"
                        product_data.product_url = product_url

                        # Collect product details
                        page.goto(product_url)
                        product_general = page.query_selector(".product-options.dl-horizontal")
                        product_dimension = page.query_selector(".col.col3")

                        product_data.name = page.evaluate('''() => {
                            const titleElement = document.querySelector('h1');
                            return titleElement ? titleElement.textContent.trim() : null;
                        }''')
                        product_data.brand = product_general.query_selector_all("dd")[2].text_content()
                        product_data.product_number = product_general.query_selector_all("dd")[0].text_content()
                        product_data.color = product_general.query_selector_all("dd")[1].text_content()
                        product_data.image_url = f"https:{page.query_selector(".img-polaroid").get_attribute("src")}"
                        product_data.depth = product_dimension.query_selector_all("dd")[0].text_content()
                        product_data.height = product_dimension.query_selector_all("dd")[1].text_content()
                        product_data.width = product_dimension.query_selector_all("dd")[2].text_content()
                        product_data.min_height = product_dimension.query_selector_all("dd")[3].text_content()
                        product_data.max_height = product_dimension.query_selector_all("dd")[4].text_content()
                        product_data.total_boxed_weight = product_dimension.query_selector_all("dd")[5].text_content()
                        product_data.total_product_weight = product_dimension.query_selector_all("dd")[6].text_content()

                        print(f"Product: {product_detail_link}")
                        products.append(product_data)
                except Exception as e:
                    print(f"ERROR: {e}")
                    continue

        print(f"Collected products: {products}")
        headers = ["Name", "Brand", "Product number", "Color", "Image URL", "Depth", "Height", "Width", "Min height", "Max height", "Total product weight", "Total boxed weight", "Product URL"]
        cleaned_products = [{
            headers[0]: product.name, 
            headers[1]: product.brand, 
            headers[2]: product.product_number, 
            headers[3]: product.color, 
            headers[4]: product.image_url, 
            headers[5]: product.depth, 
            headers[6]: product.height, 
            headers[7]: product.width, 
            headers[8]: product.min_height, 
            headers[9]: product.max_height, 
            headers[10]: product.total_product_weight, 
            headers[11]: product.total_boxed_weight, 
            headers[12]: product.product_url
        } for product in products]

        df = pd.DataFrame(cleaned_products, columns=headers)

        # Specify the path where you want to store the CSV file
        csv_file_path = "sourceofficefurniture.csv"

        # Write the DataFrame to a CSV file
        df.to_csv(csv_file_path, index=False)
        page.wait_for_timeout(5000)
