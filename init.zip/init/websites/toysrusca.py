from playwright.sync_api import sync_playwright
import pandas as pd
import json

# from models.product import Product

BASE_URL = "https://www.toysrus.ca/en"

with sync_playwright() as p:
    browser = p.chromium.launch()
    browser.new_context(
        permissions=['geolocation'],
        storage_state=None,
    )
    page = browser.new_page()
    page.goto(f"{BASE_URL}/toysrus/Category")

    try:
        page.click('button:has-text("ACCEPT ALL")')
    except Exception as e:
        pass

    # Get categories
    category_urls = page.eval_on_selector_all(".shopallLink.b-featured-carousel_shop-link", "links => links.map(link => link.href)")

    # Define a list to store product information
    products = []

    # Loop through each category URL
    for category_url in category_urls[:2]:
        try:
            print(f'Navigating to category: {category_url}')
            page.goto(category_url)

            # Wait for products to load
            product_urls = page.eval_on_selector_all('.b-product_tile-title.pdp-link', 'elements => elements.map(el => el.querySelector("a").href)')

            for product_url in product_urls[:10]:
                print(f"Going to product: {product_url}")
                page.goto(product_url)

                # TODO: click `Load More`
                # Show additional info
                page.query_selector("#tab-info").click()

                # Collect product information
                product_data = Product()
                product_data.name = page.query_selector(".b-product_details-name_wrapper").query_selector(".b-product_details-name").text_content()
                print(f"Name: {product_data.name}")
                product_data.product_number = page.locator("[data-attribute='SKN']").text_content()
                product_data.product_url = product_url
                product_data.image_url = page.query_selector(".b-product_carousel-image.js-zoom.m-active").query_selector(":scope > *").get_attribute("src")

                print("Collecting dimension...")

                # Item Height
                try:
                    item_height = page.locator('text=Item Height').text_content().replace("Item Height: ", "")
                    product_data.height = item_height
                except:
                    product_data.height = ""

                # Item Length
                try:
                    item_length = page.locator('text=Item Length').text_content().replace("Item Length: ", "")
                    product_data.depth = item_length
                except:
                    product_data.depth = ""

                # Item Weight
                try:
                    item_weight = page.locator('text=Item Weight').text_content().replace("Item Weight: ", "")
                    product_data.weight = item_weight
                except:
                    product_data.weight = ""

                # Item Width
                try:
                    item_width = page.locator('text=Item Width').text_content().replace("Item Width: ", "")
                    product_data.width = item_width
                except:
                    product_data.width = ""

                print("Collecting rating...")
                # Review Count
                try:
                    review_count = page.locator('.bv_numReviews_text').text_content()
                    product_data.rating_count = review_count.strip()
                except:
                    product_data.rating_count = "0 Reviews"

                # Review Value (Stars)
                try:
                    review_value = page.locator('.bv_avgRating_component_container .bv_avgRating').text_content()
                    product_data.rating_point = review_value.strip()
                except:
                    product_data.rating_point = "0"

                products.append(product_data)
        except Exception as e:
            print(f"ERROR: {e}")
            continue

    print(f"Collected products: {products}")
    headers = ["Name", "Brand", "Product number", "Color", "Image URL", "Depth", "Height", "Width", "Weight", "Min height", "Max height", "Total product weight", "Total boxed weight", "Product URL"]
    cleaned_products = [{
        headers[0]: product.name, 
        headers[1]: product.brand, 
        headers[2]: product.product_number, 
        headers[3]: product.color, 
        headers[4]: product.image_url, 
        headers[5]: product.depth, 
        headers[6]: product.height, 
        headers[7]: product.width,
        headers[8]: product.weight,
        headers[9]: product.min_height, 
        headers[10]: product.max_height, 
        headers[11]: product.total_product_weight, 
        headers[12]: product.total_boxed_weight, 
        headers[13]: product.product_url
    } for product in products]

    df = pd.DataFrame(cleaned_products, columns=headers)

    # Specify the path where you want to store the CSV file
    csv_file_path = "output/toysrusca.csv"

    # Write the DataFrame to a CSV file
    df.to_csv(csv_file_path, index=False)
    page.wait_for_timeout(5000)
