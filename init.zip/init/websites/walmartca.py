import urllib.parse
from playwright.sync_api import sync_playwright
import pandas as pd
import time
import os
from dotenv import load_dotenv

from models.product import Product

load_dotenv()
BASE_URL = "https://www.walmart.ca"
API_KEY = os.getenv("PROXY_API_KEY")

# Proxy
def get_proxy_url(url):
    payload = {"api_key": API_KEY, "url": url}
    query_string = urllib.parse.urlencode(payload)
    proxy_url = f"https://proxy.scrapeops.io/v1/?{query_string}"
    return proxy_url


def fetch_sub_product_urls(page, pagination_url, max_retries=3):
    attempt = 0
    while attempt < max_retries:
        try:
            print(f"Going to pagination: {pagination_url}")
            time.sleep(5)
            page.goto(pagination_url)

            page.wait_for_selector(".mb0", timeout=10000)
            page.wait_for_selector(".ph0-xl", timeout=10000)
            page.wait_for_selector(".pt0-xl", timeout=10000)

            sub_product_urls = []
            for item in page.query_selector_all('.mb0.ph0-xl.pt0-xl'):
                print("Collected product URLs")
                a_element = item.query_selector('div > div > a')
                if a_element:
                    href = a_element.get_attribute('href')
                    print(f"href: {href}")
                    if href:
                        sub_product_urls.append(f"{BASE_URL}{href}")

            print(f"Sub product URLs: {len(sub_product_urls)}")
            return sub_product_urls

        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            page.reload()
            attempt += 1
            time.sleep(2)  # Wait before retrying
        else:
            break
    raise Exception("Failed to retrieve sub-product URLs after multiple attempts")

with sync_playwright() as p:
    products = []

    browser = p.chromium.launch()
    browser.new_context(
        permissions=['geolocation'],
        storage_state=None,
    )
    page = browser.new_page()
    for _ in range(3):
        try:
            page.goto(get_proxy_url(f"{BASE_URL}/en/all-departments"))
        except Exception as e:
            page.reload()
            continue
        else:
            break

    # Get departments
    page.wait_for_selector(".pv1.pv0-m", timeout=100000)
    department_urls = [item.query_selector(':scope > *').get_attribute('href') for item in page.query_selector_all(".pv1.pv0-m")]
    department_cleaned_urls = []
    for item in department_urls:
        if BASE_URL in item:
            department_cleaned_urls.append(item)
        else:
            department_cleaned_urls.append(f"{BASE_URL}{item}")

    print(f"Department urls length: {len(department_cleaned_urls)}")

    # Define a list to store product information
    products = []

    # Loop through each category URL
    for department_url in department_cleaned_urls[:1]:
        try:
            print(f'Navigating to department: {department_url}')
            for _ in range(3):
                try:
                    page.goto(get_proxy_url(department_url))                    
                    # Wait for products to load
                    page.wait_for_selector('[aria-label="pagination"]')
                except Exception as e:
                    page.reload()
                    continue
                else:
                    break

            product_urls = []

            # Get max pagination number
            pagination = page.locator("nav[aria-label='pagination']")
            max_page = pagination.evaluate("""() => {
                const links = Array.from(document.querySelectorAll('ul.list > li > a')).map(a => a.textContent.trim());
                const page_numbers = links.filter(link => !isNaN(link)).map(Number);
                return Math.max(...page_numbers);
            }""")

            # pagination_urls = [f'{page.url}?p={i}' for i in range(1, max_page + 1)]
            pagination_urls = [f'{page.url}?page={i}' for i in range(1, 1 + 1)]
            for pagination_url in pagination_urls:
                sub_product_urls = fetch_sub_product_urls(page, pagination_url)
                product_urls.extend(sub_product_urls)

            # Collect product details
            for product_url in product_urls[:10]:
                attempt = 0
                while attempt < 3:
                    try:
                        print(f"To product: {product_url}")
                        page.goto(get_proxy_url(product_url))
                        page.wait_for_selector("#main-title")

                        product_details = page.locator('[data-testid="ui-collapse-panel"]')
                        product_data = Product()
                        product_data.name = page.query_selector("#main-title").text_content()
                        print(f"Name: {product_data.name}")
                        product_data.others = page.query_selector(".expand-collapse-section.nl3.nr3.ph3").text_content()
                        product_data.rating_point = page.query_selector(".rating-number").text_content()
                        product_data.rating_count = page.locator('[data-testid="item-review-section-link"]').text_content().replace(" reviews", "")
                        product_data.product_url = product_url
                        products.append(product_data)
                        print(f"Products length: {len(products)}")

                    except Exception as e:
                        print(f"Attempt {attempt + 1} failed: {e}")
                        page.reload()
                        attempt += 1
                        time.sleep(2)  # Wait before retrying
                    else:
                        break

        except Exception as e:
            print(f"ERROR: {e}")
            continue

    print(f"Collected products: {products}")
    headers = ["Name", "Brand", "Product number", "Color", "Image URL", "Depth", "Height", "Width", "Weight", "Min height", "Max height", "Total product weight", "Total boxed weight", "Product URL", "Rating point", "Rating count", "Others"]
    cleaned_products = [{
        headers[0]: product.name, 
        headers[1]: product.brand, 
        headers[2]: product.product_number, 
        headers[3]: product.color, 
        headers[4]: product.image_url, 
        headers[5]: product.depth, 
        headers[6]: product.height, 
        headers[7]: product.width, 
        headers[8]: product.weight,
        headers[9]: product.min_height, 
        headers[10]: product.max_height, 
        headers[11]: product.total_product_weight, 
        headers[12]: product.total_boxed_weight, 
        headers[13]: product.product_url,
        headers[14]: product.rating_point,
        headers[15]: product.rating_count,
        headers[16]: product.others,
    } for product in products]

    df = pd.DataFrame(cleaned_products, columns=headers)

    # Specify the path where you want to store the CSV file
    csv_file_path = "output/walmartca.csv"

    # Write the DataFrame to a CSV file
    df.to_csv(csv_file_path, index=False)
    page.wait_for_timeout(5000)
