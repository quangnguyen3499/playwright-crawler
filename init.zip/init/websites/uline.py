from playwright.sync_api import sync_playwright
import pandas as pd
import time
from models.product import Product

BASE_URL = "https://www.uline.com"

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    page.goto(f"{BASE_URL}/product/BrowseWebClass.htm?dup=products")

    try:
        page.click(".modalCloseImg.simplemodal-close")
    except Exception:
        pass

    # Get categories
    category_urls = page.eval_on_selector_all(".bwc", 'elements => elements.map(el => el.querySelector("a").href)')

    # Define a list to store product information
    products = []

    # Loop through each category URL
    for category_url in category_urls[:2]:
        try:
            print(f'Navigating to category: {category_url}')
            page.goto(category_url)
            page.wait_for_load_state("networkidle")

            try:
                page.click(".modalCloseImg.simplemodal-close")
            except Exception:
                pass

            sub_category_urls = []

            # Wait for sub_category to load
            page.wait_for_selector(".groupwidthlarge")
            classfeature_items = page.query_selector(".classfeature")
            if classfeature_items:
                sub_category_urls.extend([f"{BASE_URL}{item.get_attribute('href')}" for item in classfeature_items.query_selector_all("a")])
            else:
                # If .classfeature does not exist, check for the .mainfeat class
                mainfeat_items = page.query_selector_all(".mainfeat")
                for mainfeat_item in mainfeat_items:
                    sub_category_urls.extend([f"{BASE_URL}{item.get_attribute('href')}" for item in mainfeat_item.query_selector_all("a")])

            for sub_category_url in sub_category_urls[:10]:
                attempt = 0
                while attempt < 3:
                    try:
                        print(f'Navigating to sub category: {sub_category_url}')
                        page.goto(sub_category_url)

                        try:
                            page.click(".modalCloseImg.simplemodal-close")
                        except Exception:
                            pass

                        product_urls = []
                        try:
                            classfeature_items = page.query_selector(".groupfeature")
                            if classfeature_items:
                                product_urls.extend([f"{BASE_URL}{item.get_attribute('href')}" for item in classfeature_items.query_selector_all("a")])
                            else:
                                mainfeat_items = page.query_selector_all(".mainfeat")
                                for mainfeat_item in mainfeat_items:
                                    product_urls.extend([f"{BASE_URL}{item.get_attribute('href')}" for item in mainfeat_item.query_selector_all("a")])
                        except Exception as e:
                            breakpoint()

                        for product_url in product_urls[:5]:
                            print(f'Navigating to product: {product_url}')
                            page.goto(product_url)

                            # Collect product information
                            try:
                                product_data = Product()
                                product_data.name = page.query_selector("#dvTitle").query_selector(":scope > *").text_content()
                                print(f"Name: {product_data.name}")

                                # Locate the table with id 'dvChart' and extract its data
                                others = []
                                child_table1_selector = "#dvChart table table:nth-child(1)"
                                child_table2_selector = "#dvChart table table:nth-child(2)"

                                page.wait_for_selector("#dvChart table")
                                rows1 = page.query_selector_all(f'{child_table1_selector} td')
                                print("Data from first child table:")
                                for row in rows1:
                                    cell_data = row.inner_text()
                                    print(cell_data)
                                    others.append(cell_data)

                                print("\nData from second child table:")
                                rows2 = page.query_selector_all(f'{child_table2_selector} td')
                                for row in rows2:
                                    cell_data = row.inner_text()
                                    print(cell_data)
                                    others.append(cell_data)

                            except Exception as e:
                                print(f"Error collecting product data: {e}")
                                continue

                            print(f"Table info has length: {len(others)}")
                            product_data.others = others

                            products.append(product_data)
                            print(f"--- Products length: {len(products)} ---")

                    except Exception as e:
                        print(f"Attempt {attempt + 1} failed: {e}")
                        page.reload()
                        attempt += 1
                        time.sleep(2)  # Wait before retrying
                    else:
                        break

        except Exception as e:
            print(f"ERROR: {e}")
            continue

    print(f"Collected products: {products}")
    headers = ["Name", "Brand", "Product number", "Color", "Image URL", "Depth", "Height", "Width", "Weight", "Min height", "Max height", "Total product weight", "Total boxed weight", "Product URL", "Others"]
    cleaned_products = [{
        headers[0]: product.name, 
        headers[1]: product.brand, 
        headers[2]: product.product_number, 
        headers[3]: product.color, 
        headers[4]: product.image_url, 
        headers[5]: product.depth, 
        headers[6]: product.height, 
        headers[7]: product.width, 
        headers[8]: product.weight,
        headers[9]: product.min_height, 
        headers[10]: product.max_height, 
        headers[11]: product.total_product_weight, 
        headers[12]: product.total_boxed_weight, 
        headers[13]: product.product_url,
        headers[14]: product.others,
    } for product in products]

    df = pd.DataFrame(cleaned_products, columns=headers)

    # Specify the path where you want to store the CSV file
    csv_file_path = "output/uline.csv"

    # Write the DataFrame to a CSV file
    df.to_csv(csv_file_path, index=False)
    page.wait_for_timeout(5000)
