import urllib.parse
from playwright.sync_api import sync_playwright
import pandas as pd
import time
import re
import json
import os
from dotenv import load_dotenv

from models.product import Product

load_dotenv()
BASE_URL = "https://www.amazon.ca/"
API_KEY = os.getenv("PROXY_API_KEY")

# Proxy
def get_proxy_url(url):
    payload = {"api_key": API_KEY, "url": url}
    query_string = urllib.parse.urlencode(payload)
    proxy_url = f"https://proxy.scrapeops.io/v1/?{query_string}"
    return proxy_url

with sync_playwright() as p:
    products = []

    browser = p.chromium.launch()
    page = browser.new_page()
    page.goto(get_proxy_url(BASE_URL), timeout=30000)
    page.wait_for_selector("#nav-xshop", timeout=10000)

    # Collect categories
    nav_urls = []
    menu = page.query_selector("#nav-xshop")
    nav_urls = [
        f"{BASE_URL}{category.get_attribute('href')}"
        for category in menu.query_selector_all(".nav-a")
    ]
    print(f"Nav urls: {nav_urls}")

    # Collect only 2 first categories
    for nav_url in nav_urls[:1]:
        page.goto(get_proxy_url(nav_url))
        print(f"Going to: {nav_url}")

        # Collect departments
        department_items = page.query_selector_all(
            "._p13n-zg-nav-tree-all_style_zg-browse-item__1rdKf._p13n-zg-nav-tree-all_style_zg-browse-height-small__nleKL"
        )
        department_urls = [
            (
                f"{BASE_URL}{department_item.query_selector(':scope > *').get_attribute('href')}"
            )
            for department_item in department_items
        ]
        print(f"{len(department_urls)} departments")

        for department_url in department_urls[:1]:
            page.goto(get_proxy_url(department_url))
            print(f"To department: {department_url}")

            # Scroll to load all products
            for i in range(3):
                page.mouse.wheel(0, 15000)
                time.sleep(3)

            # Collect products
            product_urls = [
                f"{BASE_URL}{item.get_attribute('href')}"
                for item in page.query_selector_all(".a-link-normal.aok-block")
            ]
            for product_url in product_urls[:10]:
                try:
                    print(f"Product: {product_url}")
                    time.sleep(10)
                    for _ in range(3):
                        try:
                            page.goto(get_proxy_url(product_url), timeout=100000)
                            for i in range(3):
                                page.mouse.wheel(0, 15000)
                                time.sleep(3)

                            product_data = Product()
                            product_general = page.query_selector("#centerCol")
                            product_image = page.query_selector("#imgTagWrapperId img")
                            product_rating = page.query_selector("#averageCustomerReviews")

                            # Extract dimensions
                            print("Collecting size...")
                            dimensions_text = product_general.inner_text()
                            dimensions_match = re.search(r'(\d+\.?\d*\s?(?:inches|cm|mm|”)?\s*x\s*\d+\.?\d*\s?(?:inches|cm|mm|”)?\s*x\s*\d+\.?\d*\s?(?:inches|cm|mm|”)?(?:\s*\([^)]+\))?)(?:,\s*(\d+\.?\d*\s?(?:inches|cm|mm|”)?\s*x\s*\d+\.?\d*\s?(?:inches|cm|mm|”)?\s*x\s*\d+\.?\d*\s?(?:inches|cm|mm|”)?(?:\s*\([^)]+\))?))*', dimensions_text)
                            if dimensions_match:
                                depth, width, height = dimensions_match.groups()[:3]
                                product_data.depth = depth
                                product_data.width = width
                                product_data.height = height
                                print(f"Size: {depth} x {width} x {height}")
                                
                            # Extract the bullet points
                            bullet_points = page.query_selector_all("ul.a-unordered-list.a-vertical.a-spacing-mini li")
                            product_data.others = [point.inner_text().strip() for point in bullet_points]

                            # Extract other details
                            print("Collecting details...")
                            product_data.brand = product_general.query_selector("#bylineInfo").text_content().strip()
                            product_data.image_url = product_image.get_attribute("src") if product_image else ""
                            product_data.product_url = product_url
                            product_data.rating_point = product_rating.query_selector(".a-icon-alt").text_content().split(' ')[0]
                            product_data.rating_count = product_rating.query_selector("#acrCustomerReviewText").text_content().split(' ')[0]
                            product_data.name = product_general.query_selector("#productTitle").text_content().strip()
                            print({json.dumps(
                                {
                                    "brand": product_data.brand,
                                    "image_url": product_data.image_url,
                                    "product_url": product_data.product_url,
                                    "rating_point": product_data.rating_point,
                                    "rating_count": product_data.rating_count,
                                    "name": product_data.name
                                }, indent=4)
                            })

                            # Additional details from technical details section
                            # tech_details = page.query_selector("#productDetails_techSpec_section_1")
                            # if tech_details:
                            #     print("has tech details")
                            #     tech_details_text = tech_details.inner_text()
                            #     product_data.product_number = re.search(r'ASIN\s+:\s+(\w+)', tech_details_text).group(1) if re.search(r'ASIN\s+:\s+(\w+)', tech_details_text) else ""
                            #     product_data.color = re.search(r'(Colour|Available colors)\s*:\s*([\w\s]+)', tech_details_text, re.IGNORECASE).group(2) if re.search(r'(Colour|Available colors)\s*:\s*([\w\s]+)', tech_details_text, re.IGNORECASE) else ""
                            #     product_data.total_product_weight = re.search(r'Item Weight\s*:\s*([\d\.\s\w]+)', tech_details_text).group(1) if re.search(r'Item Weight\s*:\s*([\d\.\s\w]+)', tech_details_text) else ""
                            #     product_data.total_boxed_weight = re.search(r'Shipping Weight\s*:\s*([\d\.\s\w]+)', tech_details_text).group(1) if re.search(r'Shipping Weight\s*:\s*([\d\.\s\w]+)', tech_details_text) else ""

                            products.append(product_data)

                        except Exception as e:
                            continue
                        else:
                            break
                except Exception as e:
                    print(f"ERROR: {e}")
                    continue

    print(f"Collected products: {len(products)}")
    headers = [
        "Name",
        "Brand",
        "Product number",
        "Color",
        "Image URL",
        "Depth",
        "Height",
        "Width",
        "Min height",
        "Max height",
        "Total product weight",
        "Total boxed weight",
        "Product URL",
        "Rating",
        "Rating count"
    ]
    cleaned_products = [
        {
            headers[0]: product.name,
            headers[1]: product.brand,
            headers[2]: product.product_number,
            headers[3]: product.color,
            headers[4]: product.image_url,
            headers[5]: product.depth,
            headers[6]: product.height,
            headers[7]: product.width,
            headers[8]: product.min_height,
            headers[9]: product.max_height,
            headers[10]: product.total_product_weight,
            headers[11]: product.total_boxed_weight,
            headers[12]: product.product_url,
            headers[13]: product.rating_point,
            headers[14]: product.rating_count
        }
        for product in products
    ]

    df = pd.DataFrame(cleaned_products, columns=headers)

    # Specify the path where you want to store the CSV file
    csv_file_path = "output/amazonca.csv"

    # Write the DataFrame to a CSV file
    df.to_csv(csv_file_path, index=False)
    page.wait_for_timeout(5000)
